package com.androidmods.aimtrainer;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  WebView web = new WebView(this);
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  web.setBackgroundColor(0xFF101010);
  web.loadUrl("file:///android_asset/index.html");
  setContentView(web);
 }
}
