# ANDROID MODS - Aim Trainer

Aplicativo Android de treinamento offline com alvos fictícios.

## Compilar pelo GitHub no celular
1. Abra seu repositório GitHub vazio.
2. Envie o conteúdo desta pasta (não a pasta externa) para a raiz do repositório.
3. Faça commit na branch `main`.
4. Abra a aba **Actions** e selecione **Build Android APK**.
5. Aguarde a compilação automática após o commit ou use **Run workflow**.
6. Abra a execução concluída e baixe o artefato `ANDROID-MODS-Aim-Trainer-APK`.
7. Extraia o ZIP do artefato e instale `app-debug.apk`.

O app funciona offline. É um simulador independente: não se conecta ao Free Fire, não lê a tela do jogo e não contém ESP real ou mira automática em partidas.
