# ANDROID MODS — projeto Android inicial

## Gerar APK usando somente o celular (compilação na nuvem)
1. Crie uma conta no GitHub e entre em github.com pelo navegador.
2. Crie um repositório novo chamado `android-mods` (pode ser privado).
3. Extraia este ZIP no celular. No GitHub, abra o repositório e use **Add file > Upload files** para enviar o conteúdo da pasta `android_mods` (incluindo a pasta oculta `.github`). Se o gerenciador de arquivos não mostrar `.github`, ative a opção de mostrar arquivos ocultos ou use o GitHub pelo navegador em modo computador.
4. Faça commit dos arquivos na branch `main`.
5. Abra a aba **Actions**, escolha **Build Android APK** e toque em **Run workflow** (ou aguarde o build automático após o commit).
6. Quando terminar com sucesso, abra a execução concluída, vá em **Artifacts** e baixe `ANDROID-MODS-debug-apk`.
7. Extraia o ZIP do artifact e toque em `app-debug.apk` para instalar. Se o Android pedir, permita a instalação para o navegador/gerenciador de arquivos usado.

## Gerar APK em computador
Abra esta pasta no Android Studio e use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Limitações desta versão
- O painel funciona localmente no aparelho; ainda não há backend sincronizado.
- A tela Equipe é apenas um rascunho: não cria contas, convites, senhas ou permissões reais.
- Não há confirmação automática de Pix nem processamento de pagamentos.
- Antes de usar com clientes ou equipe em vários aparelhos, configure um backend seguro, autenticação individual e regras de acesso. Não use esta versão para guardar dados reais de clientes ou confiar em pagamentos.
- Não inclua senhas, tokens ou chaves secretas no repositório.
